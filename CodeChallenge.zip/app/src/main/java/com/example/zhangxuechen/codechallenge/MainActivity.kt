package com.example.zhangxuechen.codechallenge

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.example.baselib.constant.FilePath.Companion.BASE_TEMPPATH
import com.example.baselib.constant.PermissionName
import com.example.baselib.constant.RequestCode
import com.example.baselib.core.BaseActivity
import com.example.baselib.coroutine.Coroutine.Companion.future
import com.example.baselib.navigator.Navigator
import com.example.baselib.utils.Message.Companion.shortToast
import com.example.baselib.utils.SaferProgrammingUtils.Companion.safe
import com.example.openapi.entities.ImageHistoryDatabase
import kotlinx.android.synthetic.main.activity_main.*
import java.io.File

class MainActivity : BaseActivity() {


    var isDatabaseInited = false

    override fun getFragment(): Fragment?  = null

    override fun getLayout(): Int = R.layout.activity_main

    override fun initData() {
        File(Environment.getExternalStorageDirectory().absolutePath+File.separator+packageName).mkdirs()
        future{
            ImageHistoryDatabase.setUp(application)
        }.next {
            isDatabaseInited = true
        }
    }

    override fun initViews(){
        take_pic.setOnClickListener {
            showCamera()
        }
        view_pics.setOnClickListener{
            showPhotos()
        }
    }

    private fun showCamera(){
        startRequestPermission (Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE){
            if(it.size==0){
                Navigator().activity(this@MainActivity).scheme("zhangxuechen")
                        .host("recordimage").launch()
                return@startRequestPermission
            }
            for(permission in it){
                safe{
                    showPermissionWarning(PermissionName.PERMISSION_NAMES[permission]!!)
                }
            }
        }
    }

    private fun showPermissionWarning(msg:String){
        shortToast("${getString(R.string.permission_required)}$msg")
    }

    private fun showPhotos(){
        if(!isDatabaseInited){
            shortToast(getString(R.string.hold_on))
            return
        }
        startRequestPermission(Manifest.permission.READ_EXTERNAL_STORAGE) {
            if(it.size==0){
                Navigator().activity(this@MainActivity).scheme("zhangxuechen")
                        .host("album").launch()
                return@startRequestPermission
            }
            for(permission in it){
                safe{
                    shortToast(PermissionName.PERMISSION_NAMES[permission]!!)
                }
            }
        }
    }
}
