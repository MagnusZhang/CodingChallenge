package com.example.baselib.core

import android.app.Application

class AppComponent{
    companion object{
        val appComponent = AppComponent()
        fun register(app:Application){
            appComponent.application = app
        }
    }
    private var app:Application? = null
    var application:Application
        get()=app!!
        set(value){
            if(app==null)
                app=value
        }
}