package com.example.imager.view.activity

import android.net.Uri
import android.os.Handler
import androidx.fragment.app.Fragment
import com.example.baselib.core.BaseActivity
import com.example.imager.R
import kotlinx.android.synthetic.main.activity_imagedetail.*
import java.io.File
import java.net.URLDecoder

class ImageDetailActivity:BaseActivity(){
    private var imagePath:String? = ""
    override fun initData() {
        imagePath  = URLDecoder.decode(intent.data?.getQueryParameter("path"),"UTF-8")
    }

    override fun getLayout(): Int  = R.layout.activity_imagedetail

    override fun getFragment(): Fragment? = null

    override fun initViews() {
        super.initViews()
        image_detail.setOnClickListener{
            finish()
        }
        image_detail.setImageURI(Uri.fromFile(File(imagePath)).toString())

    }
}