package com.example.baselib.coroutine

import com.example.baselib.coroutine.Coroutine.Companion.MAINSCOPE
import com.example.baselib.utils.SaferProgrammingUtils.Companion.safe
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.coroutines.Continuation
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.startCoroutine

class Coroutine{
    companion object{
        val MAINSCOPE = MainScope()
        fun future(block:()->Unit):CoroutineFuture = CoroutineFuture(block)
    }
}

class CoroutineFuture(val block:()->Unit){


    fun start(block: () -> Unit) = suspend{
        block.invoke()
    }

    fun next(onNext: () -> Unit){
        print("helloworld")
        GlobalScope.launch {
            start{
                safe {
                    print("helloworld2")
                    block.invoke()
                    onNext.invoke()
                }
            }.invoke()
        }
    }
}

