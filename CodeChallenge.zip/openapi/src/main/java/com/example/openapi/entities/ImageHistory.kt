package com.example.openapi.entities

import android.app.Application
import androidx.room.*

@Entity
data class ImageHistory(
        @PrimaryKey val recordId: Int,
        @ColumnInfo(name="image_name") val imageName:String?,
        @ColumnInfo(name = "created_time") val createdTime: String?,
        @ColumnInfo(name = "absolute_path") val absolutePath: String?,
        @ColumnInfo(name = "thumbnail_path") val thumbnailPath:String?
)

@Dao
interface ImageHistoryDao{
    @Query("SELECT * FROM imagehistory ORDER BY recordId DESC")
    fun getAll(): List<ImageHistory>
    @Insert
    fun insertAll(vararg imageHistorys: ImageHistory)
}

@Database(entities = arrayOf(ImageHistory::class), version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun imageHistoryDao(): ImageHistoryDao

}

class ImageHistoryDatabase{
    companion object{
        private var _IMAGE_DATABASE:AppDatabase? = null
        fun setUp(application: Application){
                _IMAGE_DATABASE = Room.databaseBuilder(
                        application,
                        AppDatabase::class.java, "database-name"
                ).build()
        }
        var IMAGE_DATABASE:AppDatabase?
            get()=_IMAGE_DATABASE
            set(value){
                if(_IMAGE_DATABASE==null)
                    _IMAGE_DATABASE = value
            }

    }

}
