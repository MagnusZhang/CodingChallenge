package com.example.baselib.core

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

abstract class BaseFragment:Fragment(){
    lateinit var contentView:View

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var view = inflater.
                inflate(getLayout(),null,true)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        contentView = view
        super.onViewCreated(view, savedInstanceState)
        initData()
        initView()
    }
    abstract fun getLayout():Int
    abstract fun initView()
    abstract fun initData()
    fun <T:View>findViewById(viewId:Int):T =
        contentView.findViewById<T>(viewId)

}