package com.example.baselib.constant

class RequestCode{
    companion object{
        val REQUEST_CODE_PERMISSIONS = 0x00
        val REQUEST_CAMERA = 0x01
    }
}