package com.example.baselib.utils

import android.widget.Toast
import com.example.baselib.core.AppComponent

class Message{
    companion object{
        fun shortToast(message:String){
            Toast.makeText(AppComponent.appComponent.application,message,Toast.LENGTH_SHORT).show()
        }
        fun longToast(message:String){
            Toast.makeText(AppComponent.appComponent.application,message,Toast.LENGTH_LONG).show()
        }
    }
}
