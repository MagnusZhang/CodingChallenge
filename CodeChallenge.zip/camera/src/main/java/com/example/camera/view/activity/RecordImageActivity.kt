package com.example.camera.view.activity

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.example.baselib.constant.FilePath
import com.example.baselib.constant.FilePath.Companion.PARENT
import com.example.baselib.constant.RequestCode
import com.example.baselib.core.BaseActivity
import com.example.baselib.coroutine.Coroutine.Companion.future
import com.example.baselib.utils.DateUtils
import com.example.baselib.utils.Message.Companion.shortToast
import com.example.camera.R
import com.example.openapi.entities.ImageHistory
import com.example.openapi.entities.ImageHistoryDatabase
import kotlinx.android.synthetic.main.activity_recordimage.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class RecordImageActivity:BaseActivity(){
    var file: File? = null
    var uri:Uri? = null
    override fun initData() {
    }
    var dirs:File? = null
    override fun initViews() {
        super.initViews()
        shortToast( File(PARENT
                + packageName + File.separator + FilePath.BASE_IMAGEPATH).absolutePath)
        btn_confirm.setOnClickListener{
            if(file_name.text.isNullOrEmpty()){
                shortToast(getString(R.string.filename_empty))
                return@setOnClickListener
            }
            if(file==null||!file!!.exists()) {
                finish()
                return@setOnClickListener
            }
            dirs = File(PARENT
                    + packageName + File.separator + FilePath.BASE_IMAGEPATH)
            Log.d("ShowPath",dirs!!.absolutePath)
            if(!dirs!!.exists())
                dirs!!.mkdirs()
            future {
                var newFile = File(PARENT  + packageName
                        + File.separator + FilePath.BASE_IMAGEPATH
                        + File.separator + System.currentTimeMillis() + ".jpg")
                if(!newFile.exists())
                    newFile.createNewFile()
                var inputStream = FileInputStream(file)
                var outStream = FileOutputStream(newFile)
                var inChannel = inputStream.channel
                var outChannel = outStream.channel
                inChannel.transferTo(0,inChannel.size(),outChannel)
                inputStream.close()
                inChannel.close()
                outStream.close()
                outChannel.close()
                file!!.delete()
                var item:ImageHistory = ImageHistory(
                        System.currentTimeMillis().toInt(),
                        file_name.text.toString(),
                        DateUtils.getDate(),
                        newFile.absolutePath,
                        newFile.absolutePath
                )
                ImageHistoryDatabase.IMAGE_DATABASE!!.imageHistoryDao().insertAll(item)
            }.next {
                finish()
            }
        }
        btn_cancel.setOnClickListener{
            if(file!=null&&file!!.exists()) {
                future{
                    file!!.delete()
                }.next {
                    finish()
                }
            }else{
                finish()
            }
        }
        file = File(PARENT + packageName + File.separator + FilePath.BASE_TEMPPATH
                + File.separator + System.currentTimeMillis() + ".jpg")
        if(!File(PARENT + packageName + File.separator + FilePath.BASE_TEMPPATH).exists())
            File(PARENT + packageName + File.separator + FilePath.BASE_TEMPPATH).mkdirs()
        var intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            uri = FileProvider.getUriForFile(this@RecordImageActivity, "com.example.zhangxuechen.codechallenge.fileprovider", file!!)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else {
            uri = Uri.fromFile(file!!)
        }
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        startActivityForResult(intent, RequestCode.REQUEST_CAMERA)
    }

    override fun getLayout(): Int = R.layout.activity_recordimage

    override fun getFragment(): Fragment? = null

    override fun onResult(requestCode: Int, data: Intent?) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            file = File(uri!!.getEncodedPath()!!)
        }
    }

    override fun onCanceled(requestCode: Int) {
        super.onCanceled(requestCode)
        finish()
    }

    override fun onBackPressed() {
        if(file!=null&&file!!.exists()) {
            future{
                file!!.delete()
            }.next {
                finish()
            }
        }else{
            finish()
        }
    }
}