package com.example.imager.view.adapter

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.baselib.core.AppComponent
import com.example.imager.R
import com.example.imager.view.activity.ImageDetailActivity
import com.example.openapi.entities.ImageHistory
import com.facebook.drawee.view.SimpleDraweeView
import java.io.File
import java.net.URLEncoder

class AlbumHolder(itemView: View):RecyclerView.ViewHolder(itemView){
    lateinit var history:ImageHistory
    fun bindData(history:ImageHistory){
        itemView.findViewById<SimpleDraweeView>(R.id.pic_thumb).setImageURI(Uri.fromFile(File(history.thumbnailPath)).toString())
        itemView.findViewById<TextView>(R.id.pic_name).text = history.imageName
        itemView.findViewById<TextView>(R.id.pic_time).text = history.createdTime
        itemView.findViewById<SimpleDraweeView>(R.id.pic_thumb).setOnClickListener {
            var intent = Intent()
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            var uri = Uri.parse("zhangxuechen://imagedetail?path=${URLEncoder.encode(history.thumbnailPath,"UTF-8")}")
            intent.data = uri
            AppComponent.appComponent.application.startActivity(intent)
        }
    }

}

class AlbumAdapter(val items:List<ImageHistory>):RecyclerView.Adapter<AlbumHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlbumHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_albumlist,null,true)
        return AlbumHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: AlbumHolder, position: Int) {
        holder.bindData(items[position])
    }


}