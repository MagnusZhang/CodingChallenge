package com.example.zhangxuechen.codechallenge

import com.example.baselib.coroutine.Coroutine.Companion.future
import kotlinx.coroutines.delay
import org.junit.Test

import org.junit.Assert.*

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    var routineVar = 1
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
        future{
            routineVar +=1
        }.next {
            assert(routineVar==2)
        }
        assert(routineVar == 1)
    }
}
