package com.example.baselib.constant

import android.Manifest

class PermissionName{
    companion object{
        val PERMISSION_NAMES = mapOf<String,String>(
                Manifest.permission.CAMERA to "the permission to use the camera",
                Manifest.permission.WRITE_EXTERNAL_STORAGE to "the permission to write the storage",
                Manifest.permission.READ_EXTERNAL_STORAGE to "the permission to read the storage"
        )
    }
}