package com.example.baselib.utils

import android.util.Log
import com.example.baselib.BuildConfig

data class ExceptionHolder(var exception:Exception? = null)



class SaferProgrammingUtils{
    companion object{
        fun safe(exceptionHolder: ExceptionHolder? = null,block:()->Unit){
         try{
            block.invoke()
         }catch(e:Exception){
            exceptionHolder?.exception = e
            if(BuildConfig.BUILD_TYPE=="debug")
                Log.e("CrashOfMe",e.stackTrace.toString())
            else
                e.printStackTrace()
         }
        }
    }
}