package com.example.baselib.core

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.example.baselib.R
import com.example.baselib.constant.RequestCode.Companion.REQUEST_CODE_PERMISSIONS

abstract class BaseActivity:AppCompatActivity(){
    private var initFlag = false


    var inited:Boolean
        get() = initFlag
        set(value){
            if(initFlag==true)
                return
            initFlag = value
        }


    override fun onResume() {
        super.onResume()
        initData()
        initBaseView()
    }

    abstract fun initData()

    var mFragment:Fragment? = null
    fun initBaseView(){
        if(inited)
            return
        mFragment = getFragment()
        if(mFragment==null)
            setContentView(getLayout())
        else{
            setContentView(R.layout.activity_base)
            supportFragmentManager.beginTransaction().add(R.id.base_activity_frame,mFragment!!).commit()
        }
        initViews()
        inited = true
    }


    abstract fun getLayout():Int
    abstract fun getFragment():Fragment?
    private lateinit var requestCallback:(Array<String>)->Unit
    open fun initViews(){}
    fun startRequestPermission(vararg permissions:String = emptyArray(),afterRequired:(Array<String>)->Unit){
        var requestlist = mutableListOf<String>()
        for(permission in permissions){
            if(ActivityCompat.checkSelfPermission(this,permission)==PackageManager.PERMISSION_DENIED){
                requestlist.add(permission)
            }
        }
        if(requestlist.size==0){
            afterRequired.invoke(emptyArray())
            return
        }
        requestCallback = afterRequired
        ActivityCompat.requestPermissions(this,permissions,REQUEST_CODE_PERMISSIONS)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        var length = permissions.size
        var failedList = mutableListOf<String>()
        for(index in 0 until length){
            if(grantResults[index] == PackageManager.PERMISSION_DENIED){
                failedList.add(permissions[index])
            }
        }
        requestCallback.invoke(failedList.toTypedArray())
        failedList.clear()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(resultCode){
            Activity.RESULT_OK->
                onResult(requestCode,data)
            Activity.RESULT_CANCELED->
                onCanceled(requestCode)
            else->{}
        }

    }
    open fun onResult(requestCode:Int,data:Intent?){
        
    }
    open fun onCanceled(requestCode:Int){

    }
}
