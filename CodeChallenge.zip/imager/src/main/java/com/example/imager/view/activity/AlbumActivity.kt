package com.example.imager.view.activity

import androidx.fragment.app.Fragment
import com.example.baselib.core.BaseActivity
import com.example.baselib.coroutine.Coroutine
import com.example.imager.view.fragment.AlbumFragment

class AlbumActivity:BaseActivity(){
    override fun initData() {
    }

    override fun getLayout(): Int = 0

    override fun getFragment(): Fragment? = AlbumFragment()

}