package com.example.imager.view.fragment

import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.baselib.core.AppComponent
import com.example.baselib.core.BaseFragment
import com.example.baselib.coroutine.Coroutine.Companion.future
import com.example.imager.R
import com.example.imager.view.adapter.AlbumAdapter
import com.example.openapi.entities.ImageHistory
import com.example.openapi.entities.ImageHistoryDatabase
import com.example.openapi.entities.ImageHistoryDatabase.Companion.IMAGE_DATABASE
import kotlinx.android.synthetic.main.fragment_album.*

class AlbumFragment: BaseFragment(){

    private var imageHistoryList:MutableList<ImageHistory> = mutableListOf()

    override fun getLayout(): Int = R.layout.fragment_album

    override fun initView() {
    }

    override fun initData() {
        var layoutManager = LinearLayoutManager(AppComponent.appComponent.application,LinearLayoutManager.VERTICAL,false)
        pic_list.layoutManager = layoutManager
        pic_list.adapter = AlbumAdapter(imageHistoryList)
        future{
            ImageHistoryDatabase.setUp(AppComponent.appComponent.application)
            var list = IMAGE_DATABASE!!.imageHistoryDao().getAll()
            list.forEach {
                imageHistoryList.add(it)
            }
        }.next {
            bindData()
        }
    }

    fun bindData(){
        pic_list.adapter?.notifyDataSetChanged()
    }


}