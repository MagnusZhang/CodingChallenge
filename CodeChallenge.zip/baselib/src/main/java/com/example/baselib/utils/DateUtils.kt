package com.example.baselib.utils

import java.text.SimpleDateFormat
import java.util.*

class DateUtils{
    companion object{
        private val formater = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        fun getDate():String = formater.format(Date())
    }
}