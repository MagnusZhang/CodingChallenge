package com.example.baselib.core

import android.app.Application
import androidx.multidex.MultiDexApplication
import com.facebook.drawee.backends.pipeline.Fresco

class BaseApplication:MultiDexApplication(){
    override fun onCreate() {
        super.onCreate()
        AppComponent.register(this)
        Fresco.initialize(this)
    }
}