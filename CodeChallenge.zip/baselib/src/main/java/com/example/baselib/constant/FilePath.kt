package com.example.baselib.constant

import android.os.Environment
import java.io.File

class FilePath{
    companion object{
        val PARENT = Environment.getExternalStorageDirectory().absolutePath+File.separator
        val BASE_IMAGEPATH = "imgs"
        val BASE_TEMPPATH = "temps"
    }
}